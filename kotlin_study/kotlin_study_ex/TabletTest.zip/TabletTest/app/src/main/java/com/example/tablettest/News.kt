package com.example.tablettest

class News (val title: String, val content: String)